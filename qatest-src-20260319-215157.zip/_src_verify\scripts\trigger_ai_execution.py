import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "qa_platform.settings")

import django  # noqa: E402

django.setup()  # noqa: E402

from django.contrib.auth import get_user_model  # noqa: E402

from autotest.models import AutoTestExecution  # noqa: E402
from autotest.services.execution_queue import enqueue_execution  # noqa: E402
from testcases.models import TestCase  # noqa: E402


def main() -> None:
    case = (
        TestCase.objects.filter(execution_type=2, steps__isnull=False)
        .distinct()
        .order_by("-id")
        .first()
    )
    if not case:
        print("no_case")
        return
    User = get_user_model()
    uid = os.environ.get("USER_ID", "").strip()
    uname = os.environ.get("USERNAME", "").strip()
    if uid.isdigit():
        user = User.objects.filter(id=int(uid)).first()
    elif uname:
        user = User.objects.filter(username=str(uname)).first()
    else:
        user = User.objects.order_by("-id").first()
    if not user:
        print("no_user")
        return
    exe = AutoTestExecution.objects.create(
        case=case,
        executor=user,
        status="pending",
        trigger_payload={},
    )
    enqueue_execution(exe.id)
    print("execution_id", exe.id)
    print("case_id", case.id)


if __name__ == "__main__":
    main()

