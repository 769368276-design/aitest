import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def main() -> None:
    import browser_use.browser.profile as bu_profile

    cls = bu_profile.BrowserProfile
    m = getattr(cls, "set_default_downloads_path")
    print("attr_type", type(m))
    fn = getattr(m, "__func__", None) or m
    print("attr_func", fn, "code_file", fn.__code__.co_filename)
    dec = getattr(cls, "__pydantic_decorators__", None)
    print("has_decorators", bool(dec))
    if dec is None:
        return
    mvs = getattr(dec, "model_validators", None)
    if not mvs:
        print("no_model_validators")
        return
    items = list(mvs.values()) if isinstance(mvs, dict) else list(mvs)
    for d in items:
        try:
            f = getattr(d, "func", None)
            if f and getattr(f, "__name__", "") == "set_default_downloads_path":
                print("decorator_func", f, "code_file", f.__code__.co_filename)
        except Exception as e:
            print("decorator_iter_error", type(e).__name__)


if __name__ == "__main__":
    main()

