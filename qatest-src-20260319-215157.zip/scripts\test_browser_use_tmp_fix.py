import os
import tempfile


def apply_fix() -> None:
    if os.name != "nt":
        return
    import browser_use.browser.profile as bu_profile

    cls = getattr(bu_profile, "BrowserLaunchArgs", None)
    original = getattr(cls, "set_default_downloads_path", None) if cls is not None else None
    if original is None:
        print("no_validator")
        return

    def _patched(self):  # type: ignore[no-untyped-def]
        if getattr(self, "downloads_path", None) is None:
            import uuid
            from pathlib import Path

            base = Path(tempfile.gettempdir()) / "browser-use-downloads"
            unique_id = str(uuid.uuid4())[:8]
            downloads_path = base / f"browser-use-downloads-{unique_id}"
            while downloads_path.exists():
                unique_id = str(uuid.uuid4())[:8]
                downloads_path = base / f"browser-use-downloads-{unique_id}"
            self.downloads_path = downloads_path
            self.downloads_path.mkdir(parents=True, exist_ok=True)
        return self

    target = getattr(original, "__func__", None) or original
    target.__code__ = _patched.__code__
    target.__defaults__ = _patched.__defaults__
    target.__kwdefaults__ = _patched.__kwdefaults__
    print("patched", target.__code__.co_filename)


def main() -> None:
    apply_fix()
    from browser_use.browser.session import BrowserSession

    b = BrowserSession(cdp_url="http://127.0.0.1:1")
    print("created", type(b).__name__)


if __name__ == "__main__":
    main()

