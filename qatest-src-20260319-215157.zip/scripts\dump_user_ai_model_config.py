import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "qa_platform.settings")

import django  # noqa: E402

django.setup()  # noqa: E402

from django.contrib.auth import get_user_model  # noqa: E402
from users.models import UserAIModelConfig  # noqa: E402


def main() -> None:
    User = get_user_model()
    users = list(User.objects.order_by("id").values("id", "username")[:20])
    print("users_head", users)

    user_id = int(os.environ.get("USER_ID", "11"))
    user = User.objects.filter(id=user_id).first()
    if not user:
        print("user_not_found", user_id)
        return
    cfg = UserAIModelConfig.objects.filter(user_id=user_id).first()
    if not cfg:
        print("cfg_not_found", user_id)
        return

    def key_flag(v: str) -> str:
        s = (v or "").strip()
        return f"len={len(s)}" if s else "empty"

    print("user_id", user_id)
    print("testcase_provider", cfg.testcase_provider)
    print("testcase_model", cfg.testcase_model)
    print("testcase_base_url", cfg.testcase_base_url)
    print("testcase_api_key", key_flag(cfg.testcase_api_key))
    print("exec_provider", cfg.exec_provider)
    print("exec_model", cfg.exec_model)
    print("exec_base_url", cfg.exec_base_url)
    print("exec_api_key", key_flag(cfg.exec_api_key))
    print("ocr_provider", cfg.ocr_provider)
    print("ocr_model", cfg.ocr_model)
    print("ocr_base_url", cfg.ocr_base_url)
    print("ocr_api_key", key_flag(cfg.ocr_api_key))


if __name__ == "__main__":
    main()

