from django.apps import AppConfig


class AutotestConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "autotest"

    def ready(self):
        import os
        from django.conf import settings

        if not settings.DEBUG:
            return
        if os.environ.get("RUN_MAIN") != "true":
            return
        from autotest.services.execution_queue import start_worker
        start_worker()
