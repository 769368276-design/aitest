import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "qa_platform.settings")

import django  # noqa: E402

django.setup()  # noqa: E402

from django.conf import settings  # noqa: E402

from autotest.models import AutoTestExecution  # noqa: E402
from autotest.services.execution_queue import build_runner  # noqa: E402


def main() -> None:
    exe = AutoTestExecution.objects.order_by("-id").first()
    if not exe:
        print("no_execution")
        return
    payload = getattr(exe, "trigger_payload", None)
    payload = payload if isinstance(payload, dict) else {}
    engine = str(payload.get("engine") or getattr(settings, "AI_EXEC_ENGINE", "") or "").strip().lower()
    print("execution_id", exe.id)
    print("status", exe.status)
    print("engine", engine or "(default)")
    try:
        runner = build_runner(exe)
    except Exception as e:
        print("build_runner_error", type(e).__name__, str(e))
        raise
    print("runner_class", runner.__class__.__module__ + "." + runner.__class__.__name__)


if __name__ == "__main__":
    main()

