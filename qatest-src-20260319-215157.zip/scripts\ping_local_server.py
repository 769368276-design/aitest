import socket


def main() -> None:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2)
        s.connect(("127.0.0.1", 8000))
        print("tcp_connect", True)
        try:
            s.sendall(b"GET / HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n")
            data = s.recv(200)
            print("recv_len", len(data))
            print("recv_head", data[:80])
        except Exception as e:
            print("io_error", type(e).__name__, str(e))
    except Exception as e:
        print("connect_error", type(e).__name__, str(e))
    finally:
        try:
            s.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
