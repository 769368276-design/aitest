import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "qa_platform.settings")

import django  # noqa: E402

django.setup()  # noqa: E402

from testcases.models import TestCase  # noqa: E402


def main() -> None:
    cid = os.environ.get("CASE_ID", "").strip()
    if not cid.isdigit():
        print("missing_CASE_ID")
        return
    case = TestCase.objects.get(id=int(cid))
    steps = list(case.steps.all().order_by("step_number"))
    print("case_id", case.id)
    print("title", case.title)
    print("steps_count", len(steps))
    for s in steps:
        print("step", s.step_number, (s.description or "")[:120])


if __name__ == "__main__":
    main()

