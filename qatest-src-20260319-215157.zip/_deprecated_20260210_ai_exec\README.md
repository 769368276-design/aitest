本目录为自动备份的旧版 AI 执行相关实现，已废弃。

还原原则：
- 以 qatest_src_20260205_2104.zip 为唯一真源；
- 现有 AI 执行链路（用例步骤读取、浏览器操作、账号读取、断言、稳定性策略）均以 zip 内对应实现为准；
- 如需再次修改，请以 zip 版本为基线在同目录文件上做增量变更，避免形成多套行为。

范围：
- autotest/services、autotest/utils、autotest/templates/autotest、autotest/management/commands、autotest/apps.py、autotest/urls.py、autotest/views.py

