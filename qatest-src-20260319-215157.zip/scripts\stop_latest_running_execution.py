import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "qa_platform.settings")

import django  # noqa: E402

django.setup()  # noqa: E402

from autotest.models import AutoTestExecution  # noqa: E402


def main() -> None:
    exe = AutoTestExecution.objects.filter(status="running").order_by("-id").first()
    if not exe:
        print("no_running_execution")
        return
    exe.stop_signal = True
    exe.save(update_fields=["stop_signal"])
    print("stopped", exe.id)


if __name__ == "__main__":
    main()

