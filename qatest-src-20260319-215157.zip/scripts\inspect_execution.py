import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "qa_platform.settings")

import django  # noqa: E402

django.setup()  # noqa: E402

from autotest.models import AutoTestExecution  # noqa: E402


def main() -> None:
    eid = os.environ.get("EXECUTION_ID", "").strip()
    if not eid.isdigit():
        print("missing_EXECUTION_ID")
        return
    exe = AutoTestExecution.objects.get(id=int(eid))
    print("execution_id", exe.id)
    print("status", exe.status)
    print("executor_id", getattr(exe.executor, "id", None))
    print("steps", exe.step_records.count())
    last = exe.step_records.order_by("-step_number").first()
    if last:
        print("last_step", last.step_number, last.status, (last.description or "")[:60])
        print("has_screenshot", bool(last.screenshot_after))
        if last.error_message:
            print("error_prefix", str(last.error_message)[:160])
    if exe.result_summary:
        rs = exe.result_summary or {}
        print("summary_keys", list(rs.keys())[:12])
        try:
            if isinstance(rs.get("step_completion"), dict):
                print("step_completion", rs.get("step_completion"))
        except Exception:
            pass
        try:
            if rs.get("stop_reason") is not None:
                print("stop_reason", rs.get("stop_reason"))
        except Exception:
            pass
        try:
            if rs.get("error") is not None:
                print("error", str(rs.get("error"))[:220])
        except Exception:
            pass
        try:
            if rs.get("detail"):
                print("detail_prefix", str(rs.get("detail"))[:220])
        except Exception:
            pass
        try:
            if rs.get("traceback"):
                print("traceback_tail", str(rs.get("traceback"))[-1200:])
        except Exception:
            pass

    first0 = exe.step_records.order_by("step_number").first()
    if first0:
        try:
            print("first_step", first0.step_number, first0.status, (first0.description or "")[:60])
            if first0.ai_thought:
                print("first_thought_prefix", str(first0.ai_thought)[:220])
        except Exception:
            pass


if __name__ == "__main__":
    main()
