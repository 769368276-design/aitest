
import logging
logger = logging.getLogger(__name__)

def log_debug(msg):
    with open("d:\\Test AI\\Test pt\\debug_upload.log", "a", encoding="utf-8") as f:
        f.write(str(msg) + "\n")
