from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class StopPolicyConfig:
    submit_observation_wait_ms: int = 900
    stop_check_min_step: int = 2
    non_blocking_note_max: int = 20


@dataclass(frozen=True)
class StopDecision:
    stop: bool
    stop_reason: str = ""
    blocking: bool = False
    create_bug: bool = False
    note: str = ""


class StopPolicy:
    def __init__(self, config: StopPolicyConfig | None = None):
        self.config = config or StopPolicyConfig()

    @classmethod
    def from_settings(cls, settings_obj) -> "StopPolicy":
        try:
            cfg = StopPolicyConfig(
                submit_observation_wait_ms=int(getattr(settings_obj, "AI_EXEC_SUBMIT_OBSERVE_WAIT_MS", 900) or 900),
                stop_check_min_step=int(getattr(settings_obj, "AI_EXEC_STOP_CHECK_MIN_STEP", 2) or 2),
                non_blocking_note_max=int(getattr(settings_obj, "AI_EXEC_NON_BLOCKING_NOTE_MAX", 20) or 20),
            )
        except Exception:
            cfg = StopPolicyConfig()
        return cls(cfg)

    @classmethod
    def from_settings_and_overrides(cls, settings_obj, overrides: dict | None) -> "StopPolicy":
        base = cls.from_settings(settings_obj).config
        ov = overrides if isinstance(overrides, dict) else {}
        def _pick_int(key: str, default: int) -> int:
            try:
                v = ov.get(key, default)
                return int(v)
            except Exception:
                return int(default)
        cfg = StopPolicyConfig(
            submit_observation_wait_ms=_pick_int("submit_observation_wait_ms", base.submit_observation_wait_ms),
            stop_check_min_step=_pick_int("stop_check_min_step", base.stop_check_min_step),
            non_blocking_note_max=_pick_int("non_blocking_note_max", base.non_blocking_note_max),
        )
        return cls(cfg)

    def should_run_stop_check(self, step_number: int) -> bool:
        try:
            return int(step_number) >= int(self.config.stop_check_min_step)
        except Exception:
            return False

    def submit_wait_ms(self) -> int:
        try:
            return max(0, int(self.config.submit_observation_wait_ms))
        except Exception:
            return 900

    def should_escalate_non_blocking_on_step_done(self, has_non_blocking_notes: bool) -> bool:
        return bool(has_non_blocking_notes)

    def decide_after_blocking_check(self, ok: bool) -> StopDecision:
        if ok:
            return StopDecision(stop=False)
        return StopDecision(stop=True, stop_reason="assert_failed", blocking=True, create_bug=True)

    def decide_after_non_blocking_escalation(self, should_escalate: bool) -> StopDecision:
        if not should_escalate:
            return StopDecision(stop=False)
        return StopDecision(stop=True, stop_reason="non_blocking_bug", blocking=True, create_bug=True)
