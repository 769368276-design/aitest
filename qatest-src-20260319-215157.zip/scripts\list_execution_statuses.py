import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "qa_platform.settings")

import django  # noqa: E402

django.setup()  # noqa: E402

from autotest.models import AutoTestExecution  # noqa: E402


def main() -> None:
    counts = {}
    for st in AutoTestExecution.objects.values_list("status", flat=True):
        s = str(st or "")
        counts[s] = counts.get(s, 0) + 1
    print("counts", counts)
    running_ids = list(AutoTestExecution.objects.filter(status="running").order_by("-id").values_list("id", flat=True)[:20])
    if running_ids:
        print("running_ids", running_ids)
    latest = list(AutoTestExecution.objects.order_by("-id").values_list("id", "status")[:10])
    print("latest", latest)


if __name__ == "__main__":
    main()
